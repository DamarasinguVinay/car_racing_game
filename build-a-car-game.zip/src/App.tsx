import { useCallback, useEffect, useRef, useState } from "react";

// Game constants
const GAME_WIDTH = 400;
const GAME_HEIGHT = 600;
const CAR_WIDTH = 50;
const CAR_HEIGHT = 90;
const LANES = [70, 175, 280]; // x positions (left of car) for 3 lanes
const OBSTACLE_WIDTH = 50;
const OBSTACLE_HEIGHT = 90;

type Obstacle = {
  id: number;
  lane: number;
  y: number;
  color: string;
};

type Coin = {
  id: number;
  lane: number;
  y: number;
};

const OBSTACLE_COLORS = ["#ef4444", "#f97316", "#eab308", "#a855f7", "#06b6d4"];

function Car({
  x,
  y,
  color = "#3b82f6",
  accent = "#1e40af",
}: {
  x: number;
  y: number;
  color?: string;
  accent?: string;
}) {
  return (
    <svg
      width={CAR_WIDTH}
      height={CAR_HEIGHT}
      viewBox="0 0 50 90"
      style={{
        position: "absolute",
        left: x,
        top: y,
        transition: "left 120ms ease-out",
        filter: "drop-shadow(0 4px 6px rgba(0,0,0,0.4))",
      }}
    >
      {/* Body */}
      <rect x="5" y="10" width="40" height="70" rx="8" fill={color} />
      {/* Roof / windshield */}
      <rect x="9" y="20" width="32" height="20" rx="4" fill="#0f172a" opacity="0.85" />
      <rect x="9" y="50" width="32" height="18" rx="4" fill="#0f172a" opacity="0.85" />
      {/* Hood stripes */}
      <rect x="22" y="10" width="2" height="70" fill={accent} opacity="0.6" />
      <rect x="26" y="10" width="2" height="70" fill={accent} opacity="0.6" />
      {/* Wheels */}
      <rect x="0" y="18" width="6" height="16" rx="2" fill="#111827" />
      <rect x="44" y="18" width="6" height="16" rx="2" fill="#111827" />
      <rect x="0" y="56" width="6" height="16" rx="2" fill="#111827" />
      <rect x="44" y="56" width="6" height="16" rx="2" fill="#111827" />
      {/* Headlights */}
      <rect x="9" y="10" width="6" height="3" rx="1" fill="#fef3c7" />
      <rect x="35" y="10" width="6" height="3" rx="1" fill="#fef3c7" />
      {/* Taillights */}
      <rect x="9" y="77" width="6" height="3" rx="1" fill="#fca5a5" />
      <rect x="35" y="77" width="6" height="3" rx="1" fill="#fca5a5" />
    </svg>
  );
}

function Coin({ x, y }: { x: number; y: number }) {
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: 24,
        height: 24,
        borderRadius: "50%",
        background: "radial-gradient(circle at 30% 30%, #fde047, #ca8a04)",
        boxShadow: "0 0 12px rgba(250,204,21,0.8)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#78350f",
        fontWeight: 900,
        fontSize: 14,
        border: "2px solid #fbbf24",
      }}
    >
      $
    </div>
  );
}

export default function App() {
  const [lane, setLane] = useState(1); // 0,1,2
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);
  const [coins, setCoins] = useState<Coin[]>([]);
  const [score, setScore] = useState(0);
  const [coinsCollected, setCoinsCollected] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    const stored = localStorage.getItem("highway-dash-high");
    return stored ? parseInt(stored, 10) : 0;
  });
  const [running, setRunning] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [roadOffset, setRoadOffset] = useState(0);
  const [speed, setSpeed] = useState(5);

  const obstacleIdRef = useRef(0);
  const coinIdRef = useRef(0);
  const spawnTimerRef = useRef(0);
  const coinTimerRef = useRef(0);
  const laneRef = useRef(lane);
  const runningRef = useRef(running);
  const speedRef = useRef(speed);

  useEffect(() => {
    laneRef.current = lane;
  }, [lane]);
  useEffect(() => {
    runningRef.current = running;
  }, [running]);
  useEffect(() => {
    speedRef.current = speed;
  }, [speed]);

  const carY = GAME_HEIGHT - CAR_HEIGHT - 20;

  const startGame = useCallback(() => {
    setObstacles([]);
    setCoins([]);
    setScore(0);
    setCoinsCollected(0);
    setLane(1);
    setSpeed(5);
    setRoadOffset(0);
    setGameOver(false);
    setRunning(true);
    spawnTimerRef.current = 0;
    coinTimerRef.current = 0;
  }, []);

  const endGame = useCallback(() => {
    setRunning(false);
    setGameOver(true);
    setHighScore((prev) => {
      const finalScore = Math.floor(scoreRef.current);
      if (finalScore > prev) {
        localStorage.setItem("highway-dash-high", String(finalScore));
        return finalScore;
      }
      return prev;
    });
  }, []);

  // Track score in ref for endGame
  const scoreRef = useRef(0);
  useEffect(() => {
    scoreRef.current = score;
  }, [score]);

  // Keyboard controls
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") {
        e.preventDefault();
        setLane((l) => Math.max(0, l - 1));
      } else if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") {
        e.preventDefault();
        setLane((l) => Math.min(2, l + 1));
      } else if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        if (!runningRef.current) startGame();
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [startGame]);

  // Touch controls — tap left/right side
  const handleTouchArea = (side: "left" | "right") => {
    if (!running) return;
    if (side === "left") setLane((l) => Math.max(0, l - 1));
    else setLane((l) => Math.min(2, l + 1));
  };

  // Main game loop
  useEffect(() => {
    if (!running) return;
    let raf: number;
    let last = performance.now();

    const loop = (now: number) => {
      const dt = Math.min(50, now - last);
      last = now;

      const currentSpeed = speedRef.current;
      const moveAmt = (currentSpeed * dt) / 16;

      // Scroll road lines
      setRoadOffset((o) => (o + moveAmt) % 60);

      // Move obstacles
      setObstacles((prev) => {
        const updated = prev
          .map((o) => ({ ...o, y: o.y + moveAmt }))
          .filter((o) => o.y < GAME_HEIGHT + 100);
        return updated;
      });

      // Move coins
      setCoins((prev) =>
        prev
          .map((c) => ({ ...c, y: c.y + moveAmt }))
          .filter((c) => c.y < GAME_HEIGHT + 50)
      );

      // Spawn obstacles
      spawnTimerRef.current += dt;
      const spawnInterval = Math.max(500, 1400 - currentSpeed * 60);
      if (spawnTimerRef.current > spawnInterval) {
        spawnTimerRef.current = 0;
        setObstacles((prev) => {
          // Avoid blocking all 3 lanes near each other
          const recent = prev.filter((o) => o.y < 150);
          const blockedLanes = new Set(recent.map((o) => o.lane));
          const available = [0, 1, 2].filter((l) => !blockedLanes.has(l));
          if (available.length === 0) return prev;
          const newLane = available[Math.floor(Math.random() * available.length)];
          return [
            ...prev,
            {
              id: obstacleIdRef.current++,
              lane: newLane,
              y: -OBSTACLE_HEIGHT,
              color: OBSTACLE_COLORS[Math.floor(Math.random() * OBSTACLE_COLORS.length)],
            },
          ];
        });
      }

      // Spawn coins
      coinTimerRef.current += dt;
      if (coinTimerRef.current > 1800) {
        coinTimerRef.current = 0;
        if (Math.random() < 0.7) {
          setCoins((prev) => [
            ...prev,
            {
              id: coinIdRef.current++,
              lane: Math.floor(Math.random() * 3),
              y: -30,
            },
          ]);
        }
      }

      // Score & speed up
      setScore((s) => s + dt * 0.01 * currentSpeed);
      setSpeed((sp) => Math.min(14, sp + dt * 0.00015));

      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [running]);

  // Collision detection
  useEffect(() => {
    if (!running) return;
    const carX = LANES[lane];
    const carRect = {
      x: carX + 4,
      y: carY + 6,
      w: CAR_WIDTH - 8,
      h: CAR_HEIGHT - 12,
    };

    // Check obstacles
    for (const o of obstacles) {
      const ox = LANES[o.lane];
      if (
        carRect.x < ox + OBSTACLE_WIDTH - 4 &&
        carRect.x + carRect.w > ox + 4 &&
        carRect.y < o.y + OBSTACLE_HEIGHT - 6 &&
        carRect.y + carRect.h > o.y + 6
      ) {
        endGame();
        return;
      }
    }

    // Check coins
    const collected: number[] = [];
    for (const c of coins) {
      const cx = LANES[c.lane] + (CAR_WIDTH - 24) / 2;
      if (
        carRect.x < cx + 24 &&
        carRect.x + carRect.w > cx &&
        carRect.y < c.y + 24 &&
        carRect.y + carRect.h > c.y
      ) {
        collected.push(c.id);
      }
    }
    if (collected.length > 0) {
      setCoins((prev) => prev.filter((c) => !collected.includes(c.id)));
      setCoinsCollected((n) => n + collected.length);
      setScore((s) => s + collected.length * 25);
    }
  }, [obstacles, coins, lane, running, carY, endGame]);

  const carX = LANES[lane];

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-slate-800 to-zinc-900 flex flex-col items-center justify-center p-4 select-none">
      <div className="mb-4 text-center">
        <h1 className="text-4xl sm:text-5xl font-black tracking-tight bg-gradient-to-r from-amber-300 via-orange-400 to-red-500 bg-clip-text text-transparent">
          🏎️ HIGHWAY DASH
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Dodge cars • Collect coins • Survive the road
        </p>
      </div>

      <div className="flex gap-4 mb-3 text-white font-mono">
        <div className="bg-slate-800/80 backdrop-blur px-4 py-2 rounded-lg border border-slate-700">
          <div className="text-xs text-slate-400 uppercase">Score</div>
          <div className="text-2xl font-bold text-amber-300">
            {Math.floor(score)}
          </div>
        </div>
        <div className="bg-slate-800/80 backdrop-blur px-4 py-2 rounded-lg border border-slate-700">
          <div className="text-xs text-slate-400 uppercase">Coins</div>
          <div className="text-2xl font-bold text-yellow-400">
            {coinsCollected}
          </div>
        </div>
        <div className="bg-slate-800/80 backdrop-blur px-4 py-2 rounded-lg border border-slate-700">
          <div className="text-xs text-slate-400 uppercase">Best</div>
          <div className="text-2xl font-bold text-emerald-400">{highScore}</div>
        </div>
        <div className="bg-slate-800/80 backdrop-blur px-4 py-2 rounded-lg border border-slate-700">
          <div className="text-xs text-slate-400 uppercase">Speed</div>
          <div className="text-2xl font-bold text-cyan-400">
            {speed.toFixed(1)}
          </div>
        </div>
      </div>

      <div
        className="relative overflow-hidden rounded-xl shadow-2xl border-4 border-slate-700"
        style={{
          width: GAME_WIDTH,
          height: GAME_HEIGHT,
          background: "#1f2937",
        }}
      >
        {/* Grass sides */}
        <div
          className="absolute top-0 left-0 h-full"
          style={{
            width: 40,
            background:
              "repeating-linear-gradient(0deg, #15803d 0, #15803d 20px, #166534 20px, #166534 40px)",
          }}
        />
        <div
          className="absolute top-0 right-0 h-full"
          style={{
            width: 40,
            background:
              "repeating-linear-gradient(0deg, #15803d 0, #15803d 20px, #166534 20px, #166534 40px)",
          }}
        />

        {/* Road */}
        <div
          className="absolute top-0"
          style={{
            left: 40,
            width: GAME_WIDTH - 80,
            height: "100%",
            background: "#374151",
          }}
        >
          {/* Lane dividers */}
          {[1, 2].map((i) => (
            <div
              key={i}
              className="absolute top-0 h-full"
              style={{
                left: ((GAME_WIDTH - 80) / 3) * i - 3,
                width: 6,
                backgroundImage:
                  "repeating-linear-gradient(0deg, #fde047 0, #fde047 30px, transparent 30px, transparent 60px)",
                backgroundPositionY: `${roadOffset}px`,
              }}
            />
          ))}
          {/* Edge lines */}
          <div className="absolute top-0 left-0 w-1 h-full bg-white opacity-80" />
          <div className="absolute top-0 right-0 w-1 h-full bg-white opacity-80" />
        </div>

        {/* Obstacles (cars going opposite direction) */}
        {obstacles.map((o) => (
          <Car
            key={o.id}
            x={LANES[o.lane]}
            y={o.y}
            color={o.color}
            accent="#000"
          />
        ))}

        {/* Coins */}
        {coins.map((c) => (
          <Coin
            key={c.id}
            x={LANES[c.lane] + (CAR_WIDTH - 24) / 2}
            y={c.y}
          />
        ))}

        {/* Player Car */}
        <Car x={carX} y={carY} color="#3b82f6" accent="#1e3a8a" />

        {/* Touch areas (invisible) */}
        <div
          className="absolute top-0 left-0 h-full w-1/2 sm:hidden"
          onTouchStart={() => handleTouchArea("left")}
        />
        <div
          className="absolute top-0 right-0 h-full w-1/2 sm:hidden"
          onTouchStart={() => handleTouchArea("right")}
        />

        {/* Start / Game Over overlay */}
        {!running && (
          <div className="absolute inset-0 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center text-white">
            {gameOver ? (
              <>
                <div className="text-6xl mb-2">💥</div>
                <h2 className="text-4xl font-black text-red-400 mb-2">
                  CRASHED!
                </h2>
                <div className="text-slate-300 mb-1">
                  Score:{" "}
                  <span className="text-amber-300 font-bold">
                    {Math.floor(score)}
                  </span>
                </div>
                <div className="text-slate-300 mb-6">
                  Coins:{" "}
                  <span className="text-yellow-400 font-bold">
                    {coinsCollected}
                  </span>
                </div>
              </>
            ) : (
              <>
                <div className="text-6xl mb-3">🏁</div>
                <h2 className="text-3xl font-black mb-2">Ready to Race?</h2>
                <p className="text-slate-300 text-sm mb-6 text-center px-6">
                  Use <kbd className="px-2 py-0.5 bg-slate-700 rounded">←</kbd>{" "}
                  <kbd className="px-2 py-0.5 bg-slate-700 rounded">→</kbd> or{" "}
                  <kbd className="px-2 py-0.5 bg-slate-700 rounded">A</kbd>{" "}
                  <kbd className="px-2 py-0.5 bg-slate-700 rounded">D</kbd> to
                  switch lanes.
                  <br />
                  On mobile, tap left or right side.
                </p>
              </>
            )}
            <button
              onClick={startGame}
              className="px-8 py-3 bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-900 font-black text-lg rounded-full shadow-lg shadow-orange-500/30 transition-transform hover:scale-105 active:scale-95"
            >
              {gameOver ? "RACE AGAIN" : "START RACING"}
            </button>
            <p className="text-xs text-slate-500 mt-3">
              Press SPACE or ENTER
            </p>
          </div>
        )}
      </div>

      {/* Mobile control buttons */}
      <div className="flex gap-4 mt-4 sm:hidden">
        <button
          onTouchStart={(e) => {
            e.preventDefault();
            setLane((l) => Math.max(0, l - 1));
          }}
          className="w-20 h-20 bg-slate-700 active:bg-slate-600 text-white text-3xl rounded-2xl shadow-lg border border-slate-600"
        >
          ◀
        </button>
        <button
          onTouchStart={(e) => {
            e.preventDefault();
            setLane((l) => Math.min(2, l + 1));
          }}
          className="w-20 h-20 bg-slate-700 active:bg-slate-600 text-white text-3xl rounded-2xl shadow-lg border border-slate-600"
        >
          ▶
        </button>
      </div>

      <p className="text-slate-500 text-xs mt-6 text-center max-w-md">
        Tip: Speed increases over time. Collect coins for bonus points (+25
        each)!
      </p>
    </div>
  );
}
